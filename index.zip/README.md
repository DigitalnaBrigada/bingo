# Bingo
To je repozitorij skupine Digitalna Brigada za prvo vajo pri predmetu RUPS.

Zagon je najlažji preko terminala, s pomočjo ukaza `npm start`.
